#!/system/bin/sh

mount -o rw,remount,rw /system
